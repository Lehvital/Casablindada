// api/webhook.js — Vercel Serverless Function
// Deploy: vercel.com → New Project → Import GitHub → Add Environment Variables
//
// VARIÁVEIS DE AMBIENTE NECESSÁRIAS (configure no painel da Vercel):
// KIWIFY_WEBHOOK_SECRET  → qualquer texto secreto (ex: minha_senha_123)
// SUPABASE_URL           → https://xyz.supabase.co
// SUPABASE_ANON_KEY      → eyJhbGci...
// ZAPI_INSTANCE          → instance123 (de z-api.io)
// ZAPI_TOKEN             → token123
// ZAPI_CLIENT_TOKEN      → client-token123
// PRODUCT_LINK           → https://pay.kiwify.com.br/apf5ky6
// PIXEL_ID               → ID do Pixel Meta (opcional)
// PIXEL_ACCESS_TOKEN     → token da API de Conversões do Meta (opcional)

export default async function handler(req, res) {
  // Só aceita POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Verificar segredo da Kiwify
  const secret = req.headers['x-kw-secret'] || req.headers['x-webhook-secret'];
  if (process.env.KIWIFY_WEBHOOK_SECRET && secret !== process.env.KIWIFY_WEBHOOK_SECRET) {
    console.error('Secret inválido:', secret);
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const body = req.body || {};
  const event = body.event || body.type || '';

  // Só processa vendas aprovadas
  const eventosVenda = ['sale.approved', 'payment.succeeded', 'order.paid', 'purchase.completed'];
  if (!eventosVenda.some(e => event.includes(e.split('.')[1]) || event === e)) {
    console.log('Evento ignorado:', event);
    return res.status(200).json({ received: true, ignored: true });
  }

  // Extrair dados do cliente e produto
  const data = body.data || body;
  const customer = data.customer || data.buyer || {};
  const product  = data.product  || data.items?.[0] || {};
  const transaction = data.transaction || data.payment || {};

  const nome     = customer.full_name || customer.name || 'Comprador';
  const primeiroNome = nome.split(' ')[0];
  const email    = customer.email || '';
  const whatsapp = (customer.mobile || customer.phone || customer.whatsapp || '').replace(/\D/g, '');
  const valor    = parseFloat(transaction.amount || transaction.total || product.price || 0);
  const comissao = valor * 0.8;
  const produtoNome = product.name || 'Casa Blindada — E-book';
  const produtoLink = process.env.PRODUCT_LINK || 'https://pay.kiwify.com.br/apf5ky6';
  const dataHoje = new Date().toLocaleDateString('pt-BR');

  const resultados = { venda: false, whatsapp: false, pixel: false, erros: [] };

  // ─── 1. REGISTRAR VENDA NO SUPABASE ─────────────────────────────────────────
  if (process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY) {
    try {
      const r = await fetch(`${process.env.SUPABASE_URL}/rest/v1/vendas`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': process.env.SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${process.env.SUPABASE_ANON_KEY}`,
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({ prod: produtoNome, valor, comissao, data: dataHoje })
      });
      resultados.venda = r.ok;
      if (!r.ok) {
        const err = await r.text();
        resultados.erros.push('Supabase: ' + err.slice(0, 100));
      }

      // Também registrar como lead fechado
      if (nome) {
        await fetch(`${process.env.SUPABASE_URL}/rest/v1/leads`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': process.env.SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${process.env.SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({
            nome, wpp: whatsapp, origem: 'kiwify_automatico',
            status: 'fechado', data: dataHoje
          })
        });
      }
    } catch (e) {
      resultados.erros.push('Supabase exception: ' + e.message);
    }
  }

  // ─── 2. WHATSAPP VIA Z-API ───────────────────────────────────────────────────
  if (whatsapp && process.env.ZAPI_INSTANCE && process.env.ZAPI_TOKEN) {
    try {
      const msg = [
        `🎉 *Acesso liberado, ${primeiroNome}!*`,
        '',
        `Seu *${produtoNome}* está pronto.`,
        '',
        `📥 Clique aqui para acessar:`,
        produtoLink,
        '',
        `Qualquer dúvida é só me chamar aqui. Sucesso! 💪`,
        '',
        `— Casa Blindada`
      ].join('\n');

      const zapiUrl = `https://api.z-api.io/instances/${process.env.ZAPI_INSTANCE}/token/${process.env.ZAPI_TOKEN}/send-text`;
      const r = await fetch(zapiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': process.env.ZAPI_CLIENT_TOKEN || ''
        },
        body: JSON.stringify({ phone: whatsapp, message: msg })
      });
      resultados.whatsapp = r.ok;
      if (!r.ok) {
        const err = await r.text();
        resultados.erros.push('Z-API: ' + err.slice(0, 100));
      }

      // Follow-up D+1 (texto extra para Z-API agendar)
      // Nota: Z-API não tem agendamento nativo. Para agendar, use Make.com ou um cron job.
      // O texto abaixo é para você enviar manualmente ou via Make no dia seguinte:
      // "Oi ${primeiroNome}! Conseguiu acessar o material? Se tiver dúvida me chama aqui 👇"

    } catch (e) {
      resultados.erros.push('Z-API exception: ' + e.message);
    }
  }

  // ─── 3. PIXEL META — API DE CONVERSÕES ──────────────────────────────────────
  if (process.env.PIXEL_ID && process.env.PIXEL_ACCESS_TOKEN && email) {
    try {
      const crypto = await import('crypto');
      const hashEmail = crypto.createHash('sha256').update(email.toLowerCase().trim()).digest('hex');
      const hashPhone = whatsapp ? crypto.createHash('sha256').update(whatsapp).digest('hex') : undefined;

      const pixelBody = {
        data: [{
          event_name: 'Purchase',
          event_time: Math.floor(Date.now() / 1000),
          action_source: 'website',
          user_data: {
            em: [hashEmail],
            ...(hashPhone ? { ph: [hashPhone] } : {})
          },
          custom_data: {
            currency: 'BRL',
            value: valor,
            content_name: produtoNome,
            content_type: 'product'
          }
        }],
        access_token: process.env.PIXEL_ACCESS_TOKEN
      };

      const r = await fetch(`https://graph.facebook.com/v19.0/${process.env.PIXEL_ID}/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pixelBody)
      });
      resultados.pixel = r.ok;
    } catch (e) {
      resultados.erros.push('Pixel: ' + e.message);
    }
  }

  console.log('Webhook processado:', { event, nome, valor, resultados });
  return res.status(200).json({ success: true, resultados });
}
