# Casa Blindada — Máquina Passiva v3
## Guia de Deploy Completo

---

## O QUE ESTÁ NESTE PACOTE

```
painel.html        → Abra no navegador. É seu centro de comando.
api/webhook.js     → Código que roda na Vercel. Recebe vendas da Kiwify.
.env.example       → Modelo das variáveis de ambiente para a Vercel.
README.md          → Este arquivo.
```

---

## ETAPA 0 — O QUE FUNCIONA SEM CONFIGURAR NADA (GRÁTIS, HOJE)

Abra `painel.html` no navegador. Já funciona:
- Gerar Kit Passivo completo (Reel + Legenda + Manychat + WhatsApp + Anúncio)
- Motor IA com Arsenal Offline (8 etapas de conteúdo)
- CRM de leads e vendas (local, no browser)
- Link Kiwify já configurado: https://pay.kiwify.com.br/apf5ky6

**Para isso funcionar agora:**
1. Abra `painel.html`
2. Vá em ✨ Kit Passivo → Gerar Kit
3. Copie a legenda e o script Manychat
4. Configure o Manychat (manychat.com, grátis)
5. Filme o Reel e poste às 18h
6. Pronto — Manychat responde automaticamente, Kiwify processa a venda

---

## ETAPA 1 — SUPABASE (Banco na nuvem — grátis)

**Por que:** Sem Supabase, os dados somem se você limpar o browser.

1. Acesse https://supabase.com → Start your project → Entrar com Google
2. New Project → Nome: `casa-blindada` → Região: `South America (São Paulo)`
3. Aguarde o projeto criar (1-2 minutos)
4. Vá em **Settings → API** → Copie:
   - `Project URL` → ex: `https://xyzxyz.supabase.co`
   - `anon public` key → ex: `eyJhbGci...`
5. Vá em **SQL Editor → New Query** → Cole o SQL abaixo → Clique Run:

```sql
CREATE TABLE IF NOT EXISTS leads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT, wpp TEXT, origem TEXT,
  status TEXT DEFAULT 'morno', data TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS vendas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  prod TEXT, valor DECIMAL, comissao DECIMAL,
  data TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "acesso_total" ON leads FOR ALL USING (true) WITH CHECK (true);
ALTER TABLE vendas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "acesso_total" ON vendas FOR ALL USING (true) WITH CHECK (true);
```

6. No painel → ⚙️ Config → Cole URL e Key → Testar → Salvar

---

## ETAPA 2 — VERCEL (Webhook — grátis)

**Por que:** Sem webhook, você precisa registrar vendas manualmente. Com webhook, aparecem automaticamente.

**Pré-requisito:** Conta no GitHub (https://github.com)

1. Crie um repositório no GitHub chamado `casa-blindada`
2. Crie a pasta `api` e suba o arquivo `webhook.js` deste pacote
3. Acesse https://vercel.com → New Project → Import do GitHub → selecione `casa-blindada` → Deploy

4. Após o deploy, vá em **Settings → Environment Variables** e adicione:

| Nome | Valor |
|------|-------|
| `KIWIFY_WEBHOOK_SECRET` | Qualquer texto secreto (ex: `minha123`) |
| `SUPABASE_URL` | URL do seu projeto Supabase |
| `SUPABASE_ANON_KEY` | Anon key do Supabase |
| `ZAPI_INSTANCE` | Instance ID do Z-API (se tiver) |
| `ZAPI_TOKEN` | Token do Z-API |
| `ZAPI_CLIENT_TOKEN` | Client Token do Z-API |
| `PRODUCT_LINK` | `https://pay.kiwify.com.br/apf5ky6` |
| `PIXEL_ID` | ID do Pixel Meta (se tiver) |
| `PIXEL_ACCESS_TOKEN` | Token da API de Conversões Meta (se tiver) |

5. Sua URL de webhook será: `https://SEU-APP.vercel.app/api/webhook`
6. Cole essa URL no painel → ⚙️ Config → URL do Webhook → Salvar

---

## ETAPA 3 — KIWIFY (Ativar webhook)

1. Entre no painel da Kiwify
2. Configurações → Webhooks → Novo webhook
3. URL: cole a URL da Vercel (`https://SEU-APP.vercel.app/api/webhook`)
4. Eventos: selecione `sale.approved`
5. Secret: cole o mesmo texto do `KIWIFY_WEBHOOK_SECRET`
6. Salvar

**Resultado:** Quando alguém comprar, a Kiwify notifica a Vercel → a Vercel registra no Supabase + manda WPP → você abre o painel e a venda já está lá.

---

## ETAPA 4 — Z-API (WhatsApp automático — R$30/mês)

1. Acesse https://z-api.io → Criar conta → Plano Básico
2. Criar instância → Conectar WhatsApp (escanear QR Code)
3. Copie: Instance ID, Token, Client Token
4. Cole no painel → ⚙️ Config → seção Z-API → Salvar
5. Cole também nas variáveis de ambiente da Vercel

---

## ETAPA 5 — PIXEL META (Opcional — rastrear conversões)

1. Acesse https://business.facebook.com
2. Gerenciador de Eventos → Criar Pixel → Copiar o ID
3. Cole no painel → ⚙️ Config → Pixel ID → Salvar
4. Para API de Conversões (mais preciso): Pixel → Configurações → Gerar token de acesso
5. Cole o token na variável `PIXEL_ACCESS_TOKEN` na Vercel

---

## RESUMO — O QUE É AUTOMÁTICO E O QUE É MANUAL

| Ação | Automático? | Requer |
|------|-------------|--------|
| Manychat responde comentário BLINDADA | ✅ Sim | Manychat configurado |
| Kiwify processa pagamento + entrega e-book | ✅ Sim | Sempre automático |
| Venda aparece no painel | ✅ Sim | Vercel + Webhook configurados |
| WPP de boas-vindas após compra | ✅ Sim | Vercel + Z-API |
| Pixel registra conversão | ✅ Sim | Vercel + Pixel + Token |
| Filmar e postar o Reel | ❌ Manual | Você, 1x por semana |
| Verificar painel e reinvestir | ❌ Manual | Você, 15 min/dia |

---

## QUANTO CUSTA

| Ferramenta | Custo |
|------------|-------|
| Supabase | Grátis (até 500MB) |
| Vercel | Grátis (até 100GB de banda) |
| Manychat | Grátis (até 1.000 contatos) |
| Z-API | ~R$30/mês |
| Kiwify | 9,99% por venda (sem mensalidade) |
| Pixel Meta | Grátis |

**Total para começar:** R$0. Z-API só quando quiser o WPP automático.

---

## SUPORTE

Qualquer dúvida técnica no deploy, abra o Claude e descreva o erro exato.
